import numpy as np
import matplotlib.pyplot as plt
from matplotlib.path import Path

from lines import midpoint_algorithm
from general import normalizer, scale_for_resolution, plot_points

from scipy.ndimage import binary_fill_holes


def scanline(points, resolution):
    width, height = resolution
    npArr = np.array(points)
    npArr = np.unique(npArr, axis=0)

    intersections = []
    for y in range(0, height):
        addPoint = 0
        lenPointsLine = len(npArr[npArr[:, 1] == y]) % 2
        for x in range(0, width):
            if addPoint == 1:
                intersections.append((x,y))

            if (x,y) in points and (x+1,y) not in points and lenPointsLine == 0:
                addPoint = 1 if addPoint == 0 else 0
    return intersections
def scan(points, resolution):
    width, height = resolution
    image = np.ones((height, width))
    # Cria um Path do matplotlib para o polígono
    path = Path(points)

    x, y = np.meshgrid(np.arange(width), np.arange(height))
    points = np.vstack((x.ravel(), y.ravel())).T

    grid = path.contains_points(points)

    image[grid.reshape(height, width)] = 0

    floodfill = binary_fill_holes(image).astype(np.uint8)

    return floodfill

def scanline2(points, resolution):
    width, height = resolution
    npArr = np.array(points)
    npArr = np.unique(npArr, axis=0)

    intersections = []
    active_segments = set()

    for y in range(height):
        # Adicione segmentos ativos à lista de interseções
        intersections.extend(active_segments)

        # Atualize os segmentos ativos
        new_segments = set()
        for segment in active_segments:
            if segment[1] > y:
                new_segments.add(segment)
        active_segments = new_segments

        # Verifique os pontos relevantes
        for x in range(width):
            if (x, y) in npArr:
                # Verifique se o ponto tem um vizinho acima ou abaixo
                if (x, y - 1) in npArr or (x, y + 1) in npArr:
                    active_segments.add((x, y))

    return intersections

def generate_triangle(rotation=0):
    points = [
        (0, 1),
        (np.sqrt(3)/2, -0.5),
        (-np.sqrt(3)/2, -0.5)
    ]
    angle = np.deg2rad(rotation)
    sin_a, cos_a = np.sin(angle), np.cos(angle)

    rotated_points = [
        (x * cos_a - y * sin_a, x * sin_a + y * cos_a) for x, y in points
    ]
    return [(float(x), float(y)) for x, y in rotated_points]

def generate_square(rotation=0):

    points = [
        (-0.5, -0.5),
        (0.5, -0.5),
        (0.5, 0.5),
        (-0.5, 0.5)
    ]

    angle = np.deg2rad(rotation)
    sin_a, cos_a = np.sin(angle), np.cos(angle)

    rotated_points = [
        (x * cos_a - y * sin_a, x * sin_a + y * cos_a) for x, y in points
    ]
    return [(float(x), float(y)) for x, y in rotated_points]

def generate_hexagon(rotation=0):
    points = []
    for i in range(6):
        points.append((np.cos(np.deg2rad(60 * i)), np.sin(np.deg2rad(60 * i))))

    angle = np.deg2rad(rotation)
    sin_a, cos_a = np.sin(angle), np.cos(angle)

    rotated_points = [
        (x * cos_a - y * sin_a, x * sin_a + y * cos_a) for x, y in points
    ]

    return [(float(x), float(y)) for x, y in rotated_points]

print(generate_triangle())
r = (300,300)
T1 = generate_triangle()
T1_n = normalizer(T1)
print(T1_n)
T1_s = scale_for_resolution(T1_n, r)
print(T1_s)
T1_f = scan(T1_s, r)
print(T1_f)

fig, ax = plt.subplots(figsize=(8, 8))
ax.imshow(T1_f, cmap='gray', origin='lower', vmin=0, vmax=1)
ax.set_xlabel('Eixo X')
ax.set_ylabel('Eixo Y')
plt.grid()
plt.show()

