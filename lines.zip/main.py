from interface import view

view()
